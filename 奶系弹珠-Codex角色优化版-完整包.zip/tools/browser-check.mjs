/* Run through a local HTTP server: /tools/browser-check.html
 * Fixture-only mutations below never enter the production build or real save.
 * Optional ?scene=play|gallery|shop|win|lose|pause|vfx renders reproducible review states.
 */
const frame = document.querySelector('#fixture');
const report = document.querySelector('#report');
const results = [];
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const scene = new URLSearchParams(location.search).get('scene');
const assert = (condition, reason) => { if(!condition) throw Error(reason); };
const preload = `
(() => {
  const memory = new Map();
  Object.defineProperty(window,'localStorage',{value:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,String(v)),removeItem:k=>memory.delete(k)}});
  window.__fixtureImages=[];
  const Image0=window.Image;
  window.Image=function(w,h){const i=new Image0(w,h);window.__fixtureImages.push(i);return i};
  window.Image.prototype=Image0.prototype;
  window.__fixtureFrames=[];
  window.requestAnimationFrame=fn=>{window.__fixtureFrames.push(fn);return window.__fixtureFrames.length};
  window.cancelAnimationFrame=()=>{};
})();`;

const html = await (await fetch('../index.html')).text();
const ready = new Promise(resolve => frame.addEventListener('load',resolve,{once:true}));
frame.srcdoc = html.replace('<head>','<head><script>'+preload+'</script>').replace("var q = location.search || '';", "var q = '?debug&level=1';");
await ready;
const w=frame.contentWindow, d=w.document;
const N=w.__NAI__;
const waitFor=async fn=>{for(let i=0;i<200;i++){if(fn())return;await sleep(50)}throw Error('等待条件超时')};
const byId=id=>d.getElementById(id);
const rect=el=>(typeof el==='string'?byId(el):el).getBoundingClientRect();
const overlap=(a,b)=>a.x<b.right&&b.x<a.right&&a.y<b.bottom&&b.y<a.bottom;
const visible=el=>{const r=rect(el);return r.width>0&&r.height>0&&w.getComputedStyle(el).display!=='none'};
const inBounds=r=>r.left>=-1&&r.top>=-1&&r.right<=w.innerWidth+1&&r.bottom<=w.innerHeight+1;
const click=id=>byId(id).click();
const close=()=>d.querySelectorAll('.screen.show [data-close]').forEach((el,i)=>{if(i===0)el.click()});
async function check(name,fn){
  try{const detail=await fn();results.push({name,pass:true,detail});}
  catch(error){results.push({name,pass:false,detail:error.message});}
}
function pointer(id,type,x,y,pid=1){byId(id).dispatchEvent(new w.PointerEvent(type,{pointerId:pid,clientX:x,clientY:y,bubbles:true,cancelable:true,pointerType:'touch'}))}
function fillItems(){for(const key of ['potion','multi','plate','time','fire','portal','thunder','transform'])N.META.items[key]=2;N.updateItemBar()}
try{
  assert(N,'调试 API 未加载');
  await waitFor(()=>w.__fixtureImages.length===14&&w.__fixtureImages.every(i=>i.complete&&i.naturalWidth));
  await sleep(1500);
  d.body.classList.add('portrait-ok');
  byId('boot').style.display='none';
  N.step(170);
  N.state.atkTimer=999;
  N.draw();
  if(scene){
    report.hidden=true;
    if(scene==='gallery')click('bGallery');
    if(scene==='shop')click('bShop');
    if(scene==='pause')click('bPause');
    if(scene==='play'){
      fillItems();
      for(let i=0;i<5;i++)N.spawn(i+2,N.view.cx+(i-2)*35,N.view.h*.64,0,-200);
      N.tick(12);
    }
    if(scene==='win'){N.state.score=12480;N.win();await sleep(1600);}
    if(scene==='lose'){N.state.score=860;N.lose();await sleep(800);}
    if(scene==='vfx'){
      const protectedNames=['暴食奶狗','弹簧奶兔','吸球豆奶','毒雾奶屎','暴食奶粉','幻影奶猫','尖叫奶鸡','终焉奶蛙'];
      const before=[], after=[];
      N.state.shake=0;N.state.cineT=0;
      for(let i=0;i<protectedNames.length;i++){
        N.startLevel(i);
        const ch=N.state.boss.char,b=N.state.boss;
        const hp=b.hp,hero=N.state.heroHP,stun=N.state.stun,brk=b.brk,breakCount=b.brkCount;
        N.state.telegraph={type:['laugh','hop','suck','fart','hop','thunder','eggs','thunder'][i],atkName:'预警',t:.42,total:1,x:b.x,aimX:N.state.cannonX,dodgeW:N.view.w*.1,combo:0};
        N.state.suck=i===2?{t:1.2,total:2.4}:null;
        N.state.atkAnim={type:i===0?'laugh':i===3?'fart':'',t:.7,total:1.5};
        N.state.beam=i===5||i===7?{x:b.x,t:.3,total:.45,w:Math.max(30,N.view.w*.09)}:null;
        N.state.rocks=i===6?[{x:b.x,y:b.y+100,r:14,life:2,rot:0}]:[];
        b.hopT=i===1||i===4?.35:0;
        before.push(JSON.stringify([hp,hero,stun,brk,breakCount]));
        N.draw();
        after.push(JSON.stringify([b.hp,N.state.heroHP,N.state.stun,b.brk,b.brkCount]));
      }
      assert(before.every((v,i)=>v===after[i]),'渲染影响了伤害、生命或眩晕');
      N.state.telegraph=null;N.state.suck=null;N.state.atkAnim=null;N.state.beam=null;N.state.rocks=[];N.state.shake=0;
      N.startLevel(0);N.draw();
      document.title='视觉特效检查通过 · 8 位 Boss';
    }
    N.draw();
    document.title='视觉检查 · '+scene;
  } else {
    await check('资源完整：13 个角色与原图鉴均可解码',()=>{assert(w.__fixtureImages.length===14,'图片数量变化');return '14/14';});
    await check('首关数值：900 HP、90 秒、5 心',()=>{assert(N.state.boss.maxHp===900&&N.state.timeMax===90&&N.state.maxHP===5,'首关数值不一致');return '900 / 90 / 5';});
    await check('战斗主按钮与摇杆：触控区域可见且在屏幕内',()=>{
      for(const id of ['bPause','stickL','stickR']){const r=rect(id);assert(r.width>=44&&r.height>=44&&inBounds(r),id+'尺寸或位置不合格');}
      assert(!overlap(rect('dock'),rect('stickR')),'工具栏覆盖右摇杆');
      return `${w.innerWidth}×${w.innerHeight}`;
    });
    await check('左摇杆横移、纵向无效、松手归零',()=>{
      const r=rect('stickL'),x=r.x+r.width/2,y=r.y+r.height/2,old=N.state.cannonX;
      pointer('stickL','pointerdown',x,y);pointer('stickL','pointermove',x+36,y);N.step(12);
      assert(N.state.cannonX>old,'横移未响应');pointer('stickL','pointerup',x+36,y);assert(N.state.stickX===0,'松手未归零');
      pointer('stickL','pointerdown',x,y);pointer('stickL','pointermove',x,y-35);assert(N.state.stickX===0,'纵向产生了位移');pointer('stickL','pointerup',x,y-35);
    });
    await check('右摇杆下拉向上发射；死区仍生效',()=>{
      const r=rect('stickR'),x=r.x+r.width/2,y=r.y+r.height/2;N.state.reloadT=0;N.state.balls.length=0;
      pointer('stickR','pointerdown',x,y,2);pointer('stickR','pointermove',x,y+30,2);assert(N.state.aim.dy<-.9&&N.state.aim.power>.5,'瞄准或蓄力变化');
      pointer('stickR','pointerup',x,y+30,2);assert(N.state.balls.length===1&&N.state.balls[0].vy<0,'松手未向上发射');
      N.state.reloadT=0;const count=N.state.balls.length;pointer('stickR','pointerdown',x,y,2);pointer('stickR','pointermove',x+1,y+1,2);pointer('stickR','pointerup',x+1,y+1,2);assert(N.state.balls.length===count,'死区误发射');
    });
    await check('暂停冻结计时，继续后恢复',()=>{
      click('bPause');assert(N.state.paused&&byId('pause').classList.contains('show'),'暂停未打开');const timer=N.state.timer;N.step(60);assert(N.state.timer===timer,'暂停期间时间变化');click('bResume');assert(!N.state.paused,'继续未恢复');
    });
    await check('更多菜单保留 6 个原功能；图鉴可打开并关闭',async()=>{
      byId('utilityMenu').open=true;
      for(const id of ['bRestart','bSound','bFull','bLevels','bGallery','bShop']){const r=rect(id);assert(r.width>=44&&r.height>=44,'菜单按钮过小：'+id);}
      click('bGallery');await sleep(40);assert(!byId('utilityMenu').open&&byId('gallery').classList.contains('show'),'菜单或图鉴状态错误');
      assert(d.querySelectorAll('.char-card').length===13,'角色数量变化');assert(N.state.paused,'图鉴未暂停战斗');close();
    });
    await check('角色升级扣除原价，等级提升，按钮位于可见卡片内',async()=>{
      N.addMilk(500);click('bGallery');await sleep(30);
      const up=byId('bUpgrade'),cost=Number(up.querySelector('small').textContent.match(/\d+/)[0]),milk=N.META.milk,lv=N.META.lv['奶蛋'];
      const a=rect(up),b=rect('charDetail');assert(inBounds(a)&&a.top>=b.top&&a.bottom<=b.bottom+1,'升级按钮被裁切');
      up.click();assert(N.META.lv['奶蛋']===lv+1&&N.META.milk===milk-cost,'升级价格或效果变化');close();return '原价 '+cost+' 奶瓶';
    });
    await check('商店保留 8 种道具；购买血瓶仍扣 30 奶瓶',()=>{
      click('bShop');assert(d.querySelectorAll('.shop-card').length===8,'商品数量变化');const milk=N.META.milk,count=N.itemCount('potion');d.querySelector('[data-buy="potion"]').click();assert(N.META.milk===milk-30&&N.itemCount('potion')===count+1,'购买扣费或库存变化');close();
    });
    await check('血瓶：满血不消耗，受伤后仍恢复 1 心',()=>{
      N.state.cineT=0;N.state.potionCd=0;const count=N.itemCount('potion'),hp=N.state.heroHP;N.useItem('potion');assert(N.itemCount('potion')===count,'满血消耗血瓶');N.hurtHero(1);assert(N.state.heroHP===hp-1,'受伤机制变化');N.useItem('potion');assert(N.state.heroHP===hp&&N.itemCount('potion')===count-1,'血瓶效果变化');
    });
    await check('全道具布局：7 个快捷道具与反弹板可点击，互不重叠',()=>{
      fillItems();const buttons=[...d.querySelectorAll('#itemBar button,#itemBar2 button'),byId('bPlate')];assert(buttons.length===8,'快捷道具数量不全');
      for(const el of buttons){const r=rect(el);assert(r.width>=44&&r.height>=44&&inBounds(r),'道具触控区域异常');assert(!overlap(r,rect('stickL'))&&!overlap(r,rect('stickR')),'道具压住摇杆');}
      for(let i=0;i<buttons.length;i++)for(let j=i+1;j<buttons.length;j++)assert(!overlap(rect(buttons[i]),rect(buttons[j])),'道具互相覆盖');
    });
    await check('反弹板：进入放置、确认后消耗库存',()=>{
      N.state.cineT=0;const n=N.itemCount('plate');N.useItem('plate');assert(N.state.placingPlate,'放置预览未开启');N.confirmPlatePlacement();assert(!N.state.placingPlate&&N.state.plates.length>0&&N.itemCount('plate')===n-1,'放置机制变化');
    });
    await check('章节面板：8 章入口完整保留',()=>{click('bLevels');assert(d.querySelectorAll('.level-item').length===8,'章节数量变化');close();});
    await check('胜利结算：解锁、统计和下一章入口完整可见',async()=>{
      N.win();await sleep(1600);assert(N.state.mode==='victory'&&byId('win').classList.contains('show'),'胜利结算未打开');assert(N.META.progress===1&&N.META.unlocked['奶狗'],'解锁进度变化');assert(inBounds(rect('bNext'))&&visible(byId('bNext')),'下一章按钮不可见');assert(byId('winMilk').textContent.startsWith('+'),'奖励未显示');
    });
    await check('下一章与失败结算保留；再试一次入口可见',async()=>{
      click('bNext');assert(N.state.chapterIndex===1,'下一章跳转错误');N.step(170);N.lose();await sleep(850);assert(N.state.mode==='lose'&&byId('lose').classList.contains('show'),'失败结算未打开');assert(inBounds(rect('bRetry')),'重试按钮不可见');
    });
    const passed=results.filter(r=>r.pass).length;
    report.querySelector('h1').textContent=`${passed}/${results.length} 项通过 · ${w.innerWidth}×${w.innerHeight}`;
    document.title=`${passed}/${results.length} · 奶系弹珠浏览器回归检查`;
    document.querySelector('#checks').innerHTML=results.map(r=>`<li class="${r.pass?'pass':'fail'}">${r.pass?'通过':'失败'}：${r.name}${r.detail?' — '+r.detail:''}</li>`).join('');
    document.querySelector('#details').textContent=JSON.stringify({viewport:[w.innerWidth,w.innerHeight],passed,total:results.length,results},null,2);
  }
}catch(error){report.hidden=false;report.querySelector('h1').textContent='测试未完成';document.querySelector('#details').textContent=error.stack;}
